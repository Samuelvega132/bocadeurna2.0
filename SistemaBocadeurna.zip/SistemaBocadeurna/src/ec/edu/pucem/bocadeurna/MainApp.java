package ec.edu.pucem.bocadeurna;

import ec.edu.pucem.bocadeurna.formulario.FrmMenuPrincipal;

public class MainApp {

	public static void main(String[] args) {
		FrmMenuPrincipal formulario=new FrmMenuPrincipal();
		formulario.setVisible(true);
	}

}
