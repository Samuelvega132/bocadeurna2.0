package ec.edu.pucem.bocadeurna.formulario;

import javax.swing.*;

import ec.edu.pucem.bocadeurna.dominio.ListaVotos;
import ec.edu.pucem.bocadeurna.dominio.Voto;

import java.util.ArrayList;

import javax.swing.*;
import java.util.ArrayList;

public class FrmResultadosProvincia extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private ListaVotos listaVotos;

    public FrmResultadosProvincia(ListaVotos listaVotos) {
        this.listaVotos = listaVotos;
        setTitle("Resultados por Provincia");
        setClosable(true);
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);
        
        JLabel lblResultados = new JLabel("Resultados por Provincia");
        lblResultados.setBounds(30, 30, 200, 25);
        getContentPane().add(lblResultados);

        // Mostrar resultados
        mostrarResultados();
    }

    private void mostrarResultados() {
        ArrayList<Voto> votos = listaVotos.getVotos();
        int y = 70;
        for (Voto voto : votos) {
            JLabel lblResultado = new JLabel(voto.getPrefecto() + ": " + voto.getCantidadVotos() + " votos en la provincia de " + voto.getPrefecto().getProvincia());
            lblResultado.setBounds(30, y, 400, 25); // Aumentar el ancho para visualización completa
            getContentPane().add(lblResultado);
            y += 30;
        }
    }
}
