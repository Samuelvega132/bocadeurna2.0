package ec.edu.pucem.bocadeurna.formulario;


import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import ec.edu.pucem.bocadeurna.dominio.ListaPrefectos;
import ec.edu.pucem.bocadeurna.dominio.ListaVotos;

import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import java.awt.CardLayout;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrmMenuPrincipal extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JDesktopPane desktopPane;
    private ListaPrefectos listaPrefectos = new ListaPrefectos();
    private ListaVotos listaVotos = new ListaVotos();

    private FrmPrefectos frmPrefectos;
    private FrmBocaDeUrna frmBocaDeUrna;
    private FrmResultadosProvincia frmResultadosProvincia;
    private FrmResultadosCanton frmResultadosCanton;

    public FrmMenuPrincipal() {
        setTitle("Sistema de Elecciones");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 598, 501);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu mnArchivo = new JMenu("Archivo");
        mnArchivo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        menuBar.add(mnArchivo);

        JMenuItem mntmSalir = new JMenuItem("Salir");
        mntmSalir.setIcon(new ImageIcon(FrmMenuPrincipal.class.getResource("/ec/edu/pucem/bocadeurna/imagen/exit.png")));
        mntmSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        mntmSalir.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        mnArchivo.add(mntmSalir);

        JMenu mnCandidatos = new JMenu("Candidatos");
        mnCandidatos.setFont(new Font("Segoe UI", Font.BOLD, 16));
        menuBar.add(mnCandidatos);

        JMenuItem mntmPrefectos = new JMenuItem("Prefectos");
        mntmPrefectos.setIcon(new ImageIcon(FrmMenuPrincipal.class.getResource("/ec/edu/pucem/bocadeurna/imagen/crear.png")));
        mntmPrefectos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmPrefectos == null || !frmPrefectos.isVisible()) {
                    frmPrefectos = new FrmPrefectos(listaPrefectos);
                    desktopPane.add(frmPrefectos);
                    frmPrefectos.setVisible(true);
                } else {
                    frmPrefectos.toFront();
                    frmPrefectos.requestFocus();
                }
            }
        });
        mnCandidatos.add(mntmPrefectos);

        JMenu mnProceso = new JMenu("Proceso");
        mnProceso.setFont(new Font("Segoe UI", Font.BOLD, 16));
        menuBar.add(mnProceso);

        JMenuItem mntmBocaDeUrna = new JMenuItem("Boca de Urna");
        mntmBocaDeUrna.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmBocaDeUrna == null || !frmBocaDeUrna.isVisible()) {
                    frmBocaDeUrna = new FrmBocaDeUrna(listaVotos, listaPrefectos);
                    desktopPane.add(frmBocaDeUrna);
                    frmBocaDeUrna.setVisible(true);
                } else {
                    frmBocaDeUrna.toFront();
                    frmBocaDeUrna.requestFocus();
                }
            }
        });
        mnProceso.add(mntmBocaDeUrna);

        JMenu mnReportes = new JMenu("Reportes");
        mnReportes.setFont(new Font("Segoe UI", Font.BOLD, 16));
        menuBar.add(mnReportes);

        JMenuItem mntmResultadosProvincia = new JMenuItem("Resultados por Provincia");
        mntmResultadosProvincia.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmResultadosProvincia == null || !frmResultadosProvincia.isVisible()) {
                    frmResultadosProvincia = new FrmResultadosProvincia(listaVotos);
                    desktopPane.add(frmResultadosProvincia);
                    frmResultadosProvincia.setVisible(true);
                } else {
                    frmResultadosProvincia.toFront();
                    frmResultadosProvincia.requestFocus();
                }
            }
        });
        mnReportes.add(mntmResultadosProvincia);

        JMenuItem mntmResultadosCanton = new JMenuItem("Resultados por Cantón");
        mntmResultadosCanton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (frmResultadosCanton == null || !frmResultadosCanton.isVisible()) {
                    frmResultadosCanton = new FrmResultadosCanton(listaVotos);
                    desktopPane.add(frmResultadosCanton);
                    frmResultadosCanton.setVisible(true);
                } else {
                    frmResultadosCanton.toFront();
                    frmResultadosCanton.requestFocus();
                }
            }
        });
        mnReportes.add(mntmResultadosCanton);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(new CardLayout(0, 0));

        desktopPane = new JDesktopPane();
        contentPane.add(desktopPane, "name_7123010558300");
    }
}

