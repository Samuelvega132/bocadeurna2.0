package ec.edu.pucem.bocadeurna.formulario;


import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;


import ec.edu.pucem.bocadeurna.dominio.ListaPrefectos;
import ec.edu.pucem.bocadeurna.dominio.Prefecto;
import ec.edu.pucem.bocadeurna.dominio.Provincias;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.*;


import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrmPrefectos extends JInternalFrame {

    private static final long serialVersionUID = 1L;
    private JTextField textFieldNombre;
    private JTextField textFieldPartido;
    private ListaPrefectos listaPrefectos;

    public FrmPrefectos(ListaPrefectos listaPrefectos) {
        this.listaPrefectos = listaPrefectos;
        setTitle("Crear Prefecto");
        setClosable(true);
        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);
        
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 30, 80, 25);
        getContentPane().add(lblNombre);
        
        textFieldNombre = new JTextField();
        textFieldNombre.setBounds(120, 30, 200, 25);
        getContentPane().add(textFieldNombre);
        textFieldNombre.setColumns(10);
        
        JLabel lblPartido = new JLabel("Partido:");
        lblPartido.setBounds(30, 66, 80, 25);
        getContentPane().add(lblPartido);
        
        textFieldPartido = new JTextField();
        textFieldPartido.setBounds(120, 66, 200, 25);
        getContentPane().add(textFieldPartido);
        textFieldPartido.setColumns(10);
        
        
        JComboBox<Provincias.Provincia> comboBoxProvincia = new JComboBox<>(Provincias.Provincia.values());
        comboBoxProvincia.setBounds(120, 106, 126, 22);
        getContentPane().add(comboBoxProvincia);
        
        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nombre = textFieldNombre.getText();
                String partido = textFieldPartido.getText();
                Provincias.Provincia provincia = (Provincias.Provincia) comboBoxProvincia.getSelectedItem();
                Prefecto prefecto = new Prefecto(nombre, partido, provincia);
                listaPrefectos.agregarPrefecto(prefecto);
                limpiarCampos();
            }
        });
        btnGuardar.setBounds(120, 174, 114, 38);
        getContentPane().add(btnGuardar);
        
        JLabel lblProvincia = new JLabel("Provincia:");
        lblProvincia.setBounds(30, 105, 80, 25);
        getContentPane().add(lblProvincia);
    }
    
    private void limpiarCampos() {
        textFieldNombre.setText("");
        textFieldPartido.setText("");
    }
}

