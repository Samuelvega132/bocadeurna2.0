package ec.edu.pucem.bocadeurna.dominio;

public class Provincias {

    public enum Provincia {
        DESCONOCIDA,
        AZUAY,
        BOLIVAR,
        CAÑAR,
        CARCHI,
        CHIMBORAZO,
        COTOPAXI,
        EL_ORO,
        ESMERALDAS,
        GALAPAGOS,
        GUAYAS,
        IMBABURA,
        LOJA,
        LOS_RIOS,
        MANABI,
        MORONA_SANTIAGO,
        NAPO,
        ORELLANA,
        PASTAZA,
        PICHINCHA,
        SANTA_ELENA,
        SANTO_DOMINGO,
        SUCUMBIOS,
        TUNGURAHUA,
        ZAMORA_CHINCHIPE
    }

    public Provincia[] getProvincias() {
        return Provincia.values();
    }
}
