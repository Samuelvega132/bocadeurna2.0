package ec.edu.pucem.bocadeurna.dominio;

public class Prefecto {
    private String nombre;
    private String partido;
    private Provincias.Provincia provincia;

    public Prefecto(String nombre, String partido, Provincias.Provincia provincia) {
        this.nombre = nombre;
        this.partido = partido;
        this.provincia = provincia;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPartido() {
        return partido;
    }

    public Provincias.Provincia getProvincia() {
        return provincia;
    }

    @Override
    public String toString() {
        return nombre;
    }
}
