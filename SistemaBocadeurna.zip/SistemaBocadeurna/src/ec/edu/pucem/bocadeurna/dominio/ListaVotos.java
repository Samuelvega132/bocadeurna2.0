package ec.edu.pucem.bocadeurna.dominio;

import java.util.ArrayList;

public class ListaVotos {
    private ArrayList<Voto> votos;

    public ListaVotos() {
        this.votos = new ArrayList<>();
    }

    public void agregarVoto(Voto voto) {
        votos.add(voto);
    }

    public ArrayList<Voto> getVotos() {
        return votos;
    }

    public int contarVotosPorProvincia(Provincias.Provincia provincia) {
        int totalVotos = 0;
        for (Voto voto : votos) {
            if (voto.getPrefecto().getProvincia() == provincia) {
                totalVotos += voto.getCantidadVotos();
            }
        }
        return totalVotos;
    }

    public int contarVotosPorCiudad(String ciudad) {
        int totalVotos = 0;
        for (Voto voto : votos) {
            if (voto.getCiudad().equalsIgnoreCase(ciudad)) {
                totalVotos += voto.getCantidadVotos();
            }
        }
        return totalVotos;
    }
}
