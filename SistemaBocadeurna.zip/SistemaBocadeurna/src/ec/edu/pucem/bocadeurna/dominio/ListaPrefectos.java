package ec.edu.pucem.bocadeurna.dominio;

import java.util.ArrayList;

public class ListaPrefectos {
    private ArrayList<Prefecto> prefectos;

    public ListaPrefectos() {
        this.prefectos = new ArrayList<>();
    }

    public void agregarPrefecto(Prefecto prefecto) {
        prefectos.add(prefecto);
    }

    public ArrayList<Prefecto> getPrefectos() {
        return prefectos;
    }

    public Prefecto getPrefectoByName(String nombre) {
        for (Prefecto prefecto : prefectos) {
            if (prefecto.getNombre().equals(nombre)) {
                return prefecto;
            }
        }
        return null;
    }
}
